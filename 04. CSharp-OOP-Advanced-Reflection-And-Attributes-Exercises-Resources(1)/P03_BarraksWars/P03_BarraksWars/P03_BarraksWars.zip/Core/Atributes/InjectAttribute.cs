﻿using System;

namespace _03BarracksFactory.Core.Atributes
{
    [AttributeUsage(AttributeTargets.Field)]
    public class InjectAttribute : Attribute
    {

    }
}